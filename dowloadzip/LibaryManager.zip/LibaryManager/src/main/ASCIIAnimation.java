package main;

public class ASCIIAnimation {
    public static void printWelcomeMessage() {
        System.out.println("\033[1;34m"); // Zila krasa
        System.out.println("██      ██ ██████   █████  ██████  ██    ██     ███    ███  █████  ███    ██  █████   ██████  ███████ ██████"); 
        System.out.println("██      ██ ██   ██ ██   ██ ██   ██  ██  ██      ████  ████ ██   ██ ████   ██ ██   ██ ██       ██      ██   ██");
        System.out.println("██      ██ ██████  ███████ ██████    ████       ██ ████ ██ ███████ ██ ██  ██ ███████ ██   ███ █████   ██████");  
        System.out.println("██      ██ ██   ██ ██   ██ ██   ██    ██        ██  ██  ██ ██   ██ ██  ██ ██ ██   ██ ██    ██ ██      ██   ██"); 
        System.out.println("███████ ██ ██████  ██   ██ ██   ██    ██        ██      ██ ██   ██ ██   ████ ██   ██  ██████  ███████ ██   ██");
        System.out.println("\033[0m"); // Atiestatīt krāsu

    }
}
